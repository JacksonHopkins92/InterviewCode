package com.example.interviewcode.api

import com.example.interviewcode.model.School
import com.example.interviewcode.model.Score
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    @GET(SCHOOLS)
    suspend fun getSchools(): Response<List<School>>

    @GET(SCORES)
    suspend fun getScores(
        @Query("dbn") dbn: String
    ): Response<List<Score>>

}

const val BASE_URL = "https://data.cityofnewyork.us/resource/"
const val SCHOOLS = "s3k6-pzi2.json"
const val SCORES = "f9bf-2cp4.json"
