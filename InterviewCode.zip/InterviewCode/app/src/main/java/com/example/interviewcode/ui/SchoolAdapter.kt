package com.example.interviewcode.ui

import android.text.Layout
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.interviewcode.databinding.SchoolListItemBinding
import com.example.interviewcode.model.School

class SchoolAdapter(val list: List<School>, val openScore: (String) -> Unit)
    : RecyclerView.Adapter<SchoolAdapter.SchoolViewHolder>() {
    inner class SchoolViewHolder(val binding: SchoolListItemBinding)
        : RecyclerView.ViewHolder(binding.root) {
        fun onBind(school: School) {
            binding.apply {
                tvSchoolName.text = school.school_name
                btnViewScore.setOnClickListener {
                    openScore(school.dbn)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SchoolViewHolder {
        return SchoolViewHolder(
            SchoolListItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: SchoolViewHolder, position: Int) {
        holder.onBind(list[position])
    }

    override fun getItemCount() = list.size

}