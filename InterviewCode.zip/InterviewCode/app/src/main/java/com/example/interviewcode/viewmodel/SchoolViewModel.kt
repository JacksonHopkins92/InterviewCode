package com.example.interviewcode.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.interviewcode.api.ApiRepositoryImpl
import com.example.interviewcode.model.UIState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class SchoolViewModel(val repository: ApiRepositoryImpl): ViewModel() {

    private val _schoolData = MutableLiveData<UIState>()
    val schoolData: LiveData<UIState> get() = _schoolData

    private val _scoreData = MutableLiveData<UIState>()
    val scoreData: LiveData<UIState> get() = _scoreData

    fun getSchools() {
        CoroutineScope(Dispatchers.IO).launch {
            repository.getSchools().collect { _schoolData.postValue(it) }
        }
    }
    fun getScores(dbn: String) {
        CoroutineScope(Dispatchers.IO).launch {
            repository.getScores(dbn).collect { _scoreData.postValue(it) }
        }
    }
}