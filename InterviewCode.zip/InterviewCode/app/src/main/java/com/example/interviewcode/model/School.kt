package com.example.interviewcode.model

data class School(
    val dbn: String,
    val school_name: String
)

data class Score(
    val dbn: String,
    val school_name: String,
    val sat_critical_reading_avg_score: String,
    val sat_math_avg_score: String,
    val sat_writing_avg_score: String
)