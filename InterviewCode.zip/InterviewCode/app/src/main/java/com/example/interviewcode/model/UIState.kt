package com.example.interviewcode.model

sealed class UIState {
    class Success<T>(val data: T): UIState()
    class Error(val msg: String): UIState()
    object Loading: UIState()
}
