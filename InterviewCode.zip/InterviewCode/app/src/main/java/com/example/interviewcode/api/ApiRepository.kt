package com.example.interviewcode.api

import com.example.interviewcode.model.UIState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

interface ApiRepository {
    suspend fun getSchools(): Flow<UIState>
    suspend fun getScores(dbn: String): Flow<UIState>
}

class ApiRepositoryImpl(private val service: ApiService): ApiRepository {
    override suspend fun getSchools(): Flow<UIState> = flow {
        emit(UIState.Loading)

        val response = service.getSchools()

        if (response.isSuccessful) {
            emit(UIState.Success(response.body()!!))
        } else {
            emit(UIState.Error("Failed to get schools"))
        }
    }

    override suspend fun getScores(dbn: String): Flow<UIState> = flow {
        emit(UIState.Loading)

        val response = service.getScores(dbn)

        if (response.isSuccessful) {
            emit(UIState.Success(response.body()!!))
        } else {
            emit(UIState.Error("Failed to get scores"))
        }
    }
}

