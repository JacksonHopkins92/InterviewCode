package com.example.interviewcode.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.interviewcode.R
import com.example.interviewcode.databinding.FragmentSchoolBinding
import com.example.interviewcode.model.School
import com.example.interviewcode.model.UIState
import com.example.interviewcode.viewmodel.SchoolViewModel

class SchoolsFragment: Fragment() {
    private var _binding : FragmentSchoolBinding? = null
    private val binding: FragmentSchoolBinding get()= _binding!!

    private val viewModel: SchoolViewModel by lazy {
        ViewModelProvider(requireActivity())[SchoolViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSchoolBinding.inflate(layoutInflater)
        observeViewModel()
        return binding.root
    }
    private fun observeViewModel() {
        viewModel.schoolData.observe(viewLifecycleOwner) {
            when (it) {
                is UIState.Success<*> -> {
                    binding.rvSchools.apply {
                        adapter = SchoolAdapter(it.data as List<School>, ::openScore)
                        layoutManager = LinearLayoutManager(context)
                    }
                }
                else -> {}
            }
        }
    }

    fun openScore(dbn:String) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, ScoreFragment.newInstance(dbn))
            .addToBackStack(null)
            .commit()
    }
    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }
}