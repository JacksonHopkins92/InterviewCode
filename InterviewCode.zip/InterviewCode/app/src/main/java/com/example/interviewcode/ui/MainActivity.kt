package com.example.interviewcode.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.interviewcode.DI
import com.example.interviewcode.databinding.ActivityMainBinding
import com.example.interviewcode.viewmodel.SchoolViewModel

class MainActivity : AppCompatActivity() {
    private var _binding : ActivityMainBinding? = null
    private val binding : ActivityMainBinding get() = _binding!!

    private val viewModel : SchoolViewModel by lazy {
        DI.provideViewModel(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel.getSchools()
    }
}