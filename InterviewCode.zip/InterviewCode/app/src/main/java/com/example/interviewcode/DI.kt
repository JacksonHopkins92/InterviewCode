package com.example.interviewcode

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner
import com.example.interviewcode.api.ApiRepositoryImpl
import com.example.interviewcode.api.ApiService
import com.example.interviewcode.api.BASE_URL
import com.example.interviewcode.viewmodel.SchoolViewModel
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object DI {

    private val service : ApiService =
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)

    fun provideApiService() = ApiRepositoryImpl(service)
    fun provideViewModel(storeOwner: ViewModelStoreOwner) =
        createViewModel(storeOwner)[SchoolViewModel::class.java]

    private fun createViewModel(storeOwner: ViewModelStoreOwner) =
        ViewModelProvider(storeOwner, object:ViewModelProvider.Factory {
            override fun <T : ViewModel?> create(modelClass: Class<T>): T {
                return SchoolViewModel(provideApiService()) as T
            }
        })
}