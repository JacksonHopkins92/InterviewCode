package com.example.interviewcode.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.interviewcode.databinding.FragmentScoreBinding
import com.example.interviewcode.model.Score
import com.example.interviewcode.model.UIState
import com.example.interviewcode.viewmodel.SchoolViewModel

class ScoreFragment: Fragment() {
    private var _binding : FragmentScoreBinding? = null
    val binding: FragmentScoreBinding get()= _binding!!

    private val viewModel: SchoolViewModel by lazy {
        ViewModelProvider(requireActivity())[SchoolViewModel::class.java]
    }

    companion object {
        const val DBN = "DBN"
        fun newInstance(dbn:String): ScoreFragment {
            val fragment = ScoreFragment()
            val bundle = Bundle()
            bundle.putString(DBN, dbn)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentScoreBinding.inflate(layoutInflater)
        observeStart()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val paramString = arguments?.getString(DBN)
        if (paramString != null) {
            viewModel.getScores(paramString)
        }
    }

    private fun observeStart() {
        viewModel.scoreData.observe(viewLifecycleOwner) {

            when (it) {
                is UIState.Success<*> -> {
                    val score = (it.data as List<Score>).firstOrNull()
                    if (score != null) {
                        binding.apply {
                            tvScoreSchool.text = score.school_name
                            tvMath.text = score.sat_math_avg_score
                            tvReading.text = score.sat_critical_reading_avg_score
                            tvWriting.text = score.sat_writing_avg_score
                        }
                    } else {
                        binding.tvScoreSchool.text = "School does not have Scores"
                    }
                }
                is UIState.Error -> {
                    binding.tvScoreSchool.text = it.msg
                }
            }
        }
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }
}